package s_melisov.interfaces;

public interface Countable {
    int count(String path);
}
