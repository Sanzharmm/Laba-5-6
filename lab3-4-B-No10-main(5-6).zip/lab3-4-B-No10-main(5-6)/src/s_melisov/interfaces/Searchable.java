package s_melisov.interfaces;

public interface Searchable {
    String find(String path);
}
